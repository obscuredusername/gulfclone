import React from 'react';

function Adbox() {
  return (
    <div style={{ width: '100%', border: '1px solid #ccc', padding: '10px' }}>
      <p>This is your advertisement content.</p>
      {/* Add more content or ad-related elements as needed */}
    </div>
  );
}

export default Adbox;
